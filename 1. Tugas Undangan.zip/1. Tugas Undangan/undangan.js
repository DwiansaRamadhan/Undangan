document.getElementById('form-konfirmasi').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const nama = document.getElementById('nama').value;
    const alamat = document.getElementById('alamat').value;
    const kehadiran = document.getElementById('kehadiran').value;
    const pesan = document.getElementById('pesan').value;

    if (nama && alamat && kehadiran) {
        alert(`Terima kasih atas konfirmasinya, ${nama}!`);
    } else {
        alert('Harap isi semua field yang diperlukan.');
    }
});
